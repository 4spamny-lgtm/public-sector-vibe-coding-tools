﻿한글 HWP/HWPX → PDF 일괄 변환기
====================================

목표
----
실제 사용자는 Excel, VBA, Alt+F11을 전혀 사용할 필요가 없습니다.
완성된 EXE를 더블클릭하고 파일/폴더를 선택하거나 끌어놓은 뒤
[PDF 변환 시작]만 누르면 됩니다.

주요 기능
---------
- [폴더 선택]으로 폴더 안 HWP/HWPX 일괄 추가
- HWP/HWPX 파일을 창으로 드래그앤드롭
- 폴더 자체를 창으로 드래그앤드롭
- 하위 폴더 포함 옵션
- 중복 파일 자동 제거
- 원본 파일명 그대로 PDF 저장
  예: 신청서01.hwpx → 신청서01.pdf
- 원본과 같은 폴더 / 지정 폴더 중 선택
- 기존 PDF가 있을 때
  1) 자동 이름 변경(권장)
  2) 건너뛰기
  3) 덮어쓰기
- 진행률 표시
- 파일별 성공/실패 로그
- 실패 파일이 있어도 다음 파일 계속 진행
- 작업 취소
- 환경 점검
- 한컴 공식 FilePathChecker 보안모듈 사용자별 등록 도우미

필요 환경
---------
- Windows
- 데스크톱용 한컴오피스 한글이 설치되어 있어야 함
- HWPFrame.HwpObject 오토메이션 사용 가능 환경
- 이 프로그램은 기본적으로 32비트(EXE x86)로 빌드하도록 되어 있음

EXE 만들기
-----------
1. 이 압축파일을 Windows PC에 풉니다.
2. BUILD_EXE.bat 을 더블클릭합니다.
3. dist 폴더에 "한글PDF일괄변환.exe"가 생깁니다.
4. 테스트 후 실제 사용자에게는 이 EXE만 배포하면 됩니다.

대부분의 한글 설치 환경에서는 우선 x86 버전을 권장합니다.
만약 환경 점검에서 HWPFrame.HwpObject를 찾지 못하고
사용 중인 한글이 64비트인 것이 확인되면 BUILD_EXE_X64.bat도 시험해보세요.

보안모듈
--------
한글 오토메이션으로 로컬 파일을 열고 저장할 때 보안 승인창이 나타날 수 있습니다.

프로그램의 [보안모듈 설정] 버튼은 사용자가 직접 선택한
한컴 공식 FilePathCheckerModuleExample.dll을 다음 위치로 복사하고,

%LOCALAPPDATA%\HancomPdfBatch\

현재 사용자 레지스트리 아래에 등록합니다.

HKEY_CURRENT_USER\SOFTWARE\HNC\HwpAutomation\Modules

프로그램에는 한컴 DLL 자체가 포함되어 있지 않습니다.
한컴 디벨로퍼가 공식 배포하는 보안모듈을 사용하세요.

중요
----
- 암호가 걸린 문서, 배포용 문서, 손상된 문서는 변환이 실패할 수 있습니다.
- 변환 결과는 파일별 로그에서 확인하세요.
- 회사에서 여러 사용자에게 배포할 경우, 코드서명/SmartScreen/사내 보안정책을
  IT 담당자와 확인하는 것이 좋습니다.
- 한컴 오토메이션 이용 조건은 배포 목적에 따라 한컴의 최신 라이선스 정책을 확인하세요.

개발 구조
---------
src\Program.cs
  C# WinForms UI + HWPFrame.HwpObject COM 자동화

PDF 변환 핵심
-------------
1) HWPFrame.HwpObject 생성
2) 가능하면 RegisterModule("FilePathCheckDLL", 등록된 레지스트리 값 이름)
3) hwp.Open(원본경로, "", "lock:false;forceopen:true;versionwarning:false;suspendpassword:true;")
4) hwp.SaveAs(PDF경로, "PDF", "")
5) hwp.Clear(1)
6) 모든 파일 종료 후 hwp.Quit()


[중요 - 수정 V2]
빌드할 때는 기존 배치파일 대신 BUILD_EXE_SAFE.cmd 를 더블클릭하세요.
정상 빌드되면 dist 폴더에 HancomPdfBatch.exe 가 생성됩니다.

이번 수정에서는 Windows CMD 인코딩 문제를 피하기 위해
빌드 스크립트를 ASCII 전용으로 변경했고, ^ 줄연결을 제거했습니다.
또한 구형 .NET Framework 컴파일러에서 발생할 수 있는
Thread 생성자 CS0121 오류도 미리 수정했습니다.
